package com.sathu.serviceconnect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiceconnectApplicationTests {

    @Test
    void contextLoads() {
    }

}
