package com.sathu.serviceconnect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceconnectApplication {

    public static void main(String[] args) {
        SpringApplication.run(ServiceconnectApplication.class, args);
    }

}
